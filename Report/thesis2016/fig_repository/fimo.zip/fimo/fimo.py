
# Import
import os
import sys

# Parameters
motifFile = "./meme.pwm"
sequenceFile = "/home/egg/Desktop/footprint_motifmatch/MemeChip/footprints_wo_mpbs.fa"
outputLoc = "./res/"

# Execution
os.system("fimo --thresh 0.0005  --o "+outputLoc+" "+motifFile+" "+sequenceFile)


