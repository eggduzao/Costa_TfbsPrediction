
###################################################################################################
# INPUT
###################################################################################################

# Import
library(lattice)
library(reshape)
library(plotrix)

###################################################################################################
# FUNCTIONS
###################################################################################################

lineplot <- function(datacol, dataFrame, outFileName){

  colVec = c("#008000","#800000","#000080","#808000","#FF6600","#6600FF")

  minValue = min(dataFrame[,datacol])
  maxValue = max(dataFrame[,datacol])

  postscript(outFileName,width=6.0,height=5.0,horizontal=FALSE,paper='special')
  par(mar=c(2,2,1,1))
  
  plot(1:nrow(dataFrame), dataFrame[,datacol], type = "n", xlim=c(1,200), ylim=c(minValue,maxValue), xlab="", ylab="", main="", lty=1, axes = FALSE)
  lines(1:nrow(dataFrame), dataFrame[,datacol], col="black")

  axis(side = 1, at=c(1,50,101,150,200), labels = c("-100","-50","0","50","100"))
  axis(side = 2)

  dev.off()
  #system(paste("epstopdf",outFileName,sep=" "))
  #system(paste("rm",outFileName,sep=" "))

}

###################################################################################################
# EXECUTION
###################################################################################################

inLoc = "./profile/"
outLoc = "./graphs/"

dcList = c(1,2,3,4,5,6)
labelList = c("CCGGSY","SCAGGA","CKCSGAG","ACMSCG","CCGGAGHC","TACCCR")

for(dc in dcList){

  # Parameters
  inFileName = paste(inLoc,"profile.txt",sep="")
  outFileName = paste(outLoc,labelList[dc],".eps",sep="")

  # Reading table
  bx = read.table(inFileName, header=TRUE)

  # Making plot
  lineplot(dc,bx,outFileName)

}



