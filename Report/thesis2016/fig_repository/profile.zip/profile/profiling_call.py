
# Import
import os
import sys
from glob import glob

# Parameters
totalWindow="200"
il = "./input/"
mList = ["CCGGSY","SCAGGA","CKCSGAG","ACMSCG","CCGGAGHC","TACCCR"]
bedFileNameList=",".join([il+e+".bed" for e in mList])
bamFileName="/hpcwork/izkf/projects/TfbsPrediction/Data/DNase_DU/H1hesc/DNase.bam"
outFileName="./profile/profile.txt"
signalExt="1"
signalExtBoth="N"

clusterCommand = "profileGraph "
clusterCommand += totalWindow+" "+bedFileNameList+" "+bamFileName+" "+outFileName+" "+signalExt+" "+signalExtBoth
os.system(clusterCommand)


