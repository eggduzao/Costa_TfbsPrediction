
# Import
import os
import sys
from glob import glob

# Input
inFileName = "/home/egg/Desktop/fimo/res/fimo.txt"
outLoc = "/home/egg/Desktop/profile/input/"

inList = ["CCGGSY","SCAGGA","CKCSGAG","ACMSCG","CCGGAGHC","TACCCR"]

for inName in inList:

  temp1 = "./temp1.txt"
  inFile = open(inFileName,"r")
  inFile.readline()
  outFile = open(temp1,"w")
  for line in inFile:
    ll = line.strip().split("\t")
    if(ll[0] != inName): continue
    kk = ll[1].split(":")
    kkk = kk[1].split("-")
    outFile.write("\t".join([kk[0],kkk[0],kkk[1]])+"\n")
  inFile.close()
  outFile.close()

  temp2 = "./temp2.txt"
  outFileName = outLoc+inName+".bed"
  os.system("sort -k1,1 -k2,2n "+temp1+" > "+temp2)
  os.system("mergeBed -i "+temp2+" > "+outFileName)

  for e in [temp1,temp2]: os.system("rm "+e)


